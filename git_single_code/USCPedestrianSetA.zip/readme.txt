The "USC pedestrian set A" is collected from the Internet to evaluate frontal/rear view
walking/standing human detection algorithm without inter-human occlusion. This set contains 205 images,
with 313 humans. The groundtruth is provided in XML format.

If your publication includes any experimental 
results obtained on any images from this set, please acknowlege the use of the "USC pedestrian set A"
and reference the following paper:
Bo Wu, and Ram Nevatia. Detection of Multiple, Partially Occluded Humans in a Single Image by Bayesian Combination 
of Edgelet Part Detectors. ICCV'05, Beijing, China, Oct 17-20, 2005.

Without permission from USC vision group, images from within the 
dataset cannot be incorporated into a larger database which is then publicly distributed. 