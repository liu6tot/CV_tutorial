color-detection
===============

Very simple OpenCV program for tracking a single coloured object in a real-time video capture.
